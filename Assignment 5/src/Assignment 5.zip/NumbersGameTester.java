/**
 *
 * @author Luis Hernandez
 */
import java.util.Scanner;
import java.util.Random;
public class NumbersGameTester {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Random r = new Random();
        String betType;
        int betAmount;
        int playerNumber;
        //Randomly generate the winning number from 100-999
        //int winningNumber = r.nextInt(899) + 100;
        int winningNumber;
        System.out.print("Please enter bet type: ");
        betType = in.next();
        System.out.print("\nPlease enter bet amount: $");
        betAmount = in.nextInt();
        System.out.print("\nPlease enter three numbers: ");
        playerNumber = in.nextInt();
        System.out.print("\nPlease enter winning numbers: ");
        winningNumber = in.nextInt();

        NumbersGame myGame = new NumbersGame(betType, betAmount, playerNumber, winningNumber);

        System.out.println("\nThe bet type: " + myGame.getBetType() +
                "\nThe bet amount: $" + myGame.getBetAmount() +
                "\nYour numbers: " + myGame.getPlayersNumber() +
                "\nThe winning numbers: " + myGame.getWinningNumber());

        System.out.println(myGame.computeWinnings());
    }
}
